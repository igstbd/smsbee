package com.vernu.sms;

import android.app.Application;
import android.util.Log;

import androidx.work.Configuration;
import androidx.work.WorkManager;

import com.vernu.sms.database.SmsDedupeStore;
import com.vernu.sms.helpers.Diagnostics;
import com.vernu.sms.helpers.NetworkDoorbell;
import com.vernu.sms.helpers.SettingsChangeWatcher;

public class SMSGatewayApplication extends Application implements Configuration.Provider {
    private static final String TAG = "SMSGatewayApplication";
    
    @Override
    public void onCreate() {
        super.onCreate();
        Diagnostics.init(this);
        
        // Initialize WorkManager early to ensure it's ready for background work
        // This is important for background tasks like heartbeat
        try {
            WorkManager.initialize(this, getWorkManagerConfiguration());
            Log.d(TAG, "WorkManager initialized successfully");
        } catch (IllegalStateException e) {
            // WorkManager might already be initialized (e.g., by androidx.startup)
            // This is fine, we can continue
            Log.d(TAG, "WorkManager already initialized or will be initialized automatically");
        }

        // Stamps the first run and deletes the old dedupe store when due; storage is locked before the first unlock
        try {
            SmsDedupeStore.forReading(this);
        } catch (Exception e) {
            Log.w(TAG, "Old dedupe store not checked: " + e.getMessage());
        }

        registerActivityLifecycleCallbacks(new SettingsChangeWatcher());
        NetworkDoorbell.register(this);
    }
    
    @Override
    public Configuration getWorkManagerConfiguration() {
        return new Configuration.Builder()
            .setMinimumLoggingLevel(android.util.Log.INFO)
            .setMaxSchedulerLimit(50)
            .build();
    }
} 